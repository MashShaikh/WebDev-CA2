from . import views
from django.urls import path

urlpatterns = [
    path('', views.index, name = 'home'),
    path('delete/<place_name>/', views.delete_place, name='delete_place'),
]