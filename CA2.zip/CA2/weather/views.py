from django.shortcuts import render, redirect
import requests
from .models import Place
from .forms import PlaceForm


def index(request):
    url = 'https://api.openweathermap.org/data/2.5/weather?q={}&APPID=2795b95407d2dbb96f44e4109ae25f68'
    err_msg = ''
    message = ''
    
    if request.method == 'POST':
        form = PlaceForm(request.POST)
        if form.is_valid():
            new_place = form.cleaned_data['name']
            existing_city_count = Place.objects.filter(name=new_place).count()
            if existing_city_count == 0:
                r = requests.get(url.format(new_place)).json()
                if r['cod'] == 200:
                    form.save()
                else:
                    err_msg = 'City does not exist!'
            else:
                err_msg = 'City already exists!'
    
    form = PlaceForm()
    places = Place.objects.all()
    weather_info = []
    for place in places:
        r = requests.get(url.format(place)).json()
        city_weather = {
            'place' : place.name,
            'tem' : r['main']['temp'],
            'descri' : r['weather'][0]['description'],
            'icon' : r['weather'][0]['icon'],
        }
        weather_info.append(city_weather)
    context = {
        'weather_info' : weather_info, 
        'form' : form,
        'message' : message,
        }
    return render(request,'weather/weather.html', context)

def delete_place(requests, place_name):
    Place.objects.get(name=place_name).delete()
    return redirect('home')
